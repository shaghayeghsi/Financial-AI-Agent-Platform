import os
import json
from datetime import datetime

CODE_EXTENSIONS = {'.py', '.ipynb', '.json', '.yaml', '.yml', '.txt', '.md'}
output_file = "project_code_full_dump.txt"
log_file = "log_code_dump.txt"

def read_file_clean(file_path):
    try:
        if file_path.endswith(".ipynb"):
            with open(file_path, "r", encoding="utf-8") as f:
                nb = json.load(f)
                lines = []
                for cell in nb.get("cells", []):
                    if cell.get("cell_type") in {"code", "markdown"}:
                        lines.append("# --- Cell Type: " + cell["cell_type"])
                        lines.extend(cell.get("source", []))
                        lines.append("\n")
                return "".join(lines)
        else:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
    except Exception as e:
        try:
            with open(file_path, "r", encoding="latin-1") as f:
                return f.read()
        except:
            with open(log_file, "a", encoding="utf-8") as logf:
                logf.write(f"[ERROR reading] {file_path}: {str(e)}\n")
            return f"[[!! ERROR reading file: {file_path} !!]]\n\n"

def dump_clean_code(base_dir):
    output_path = os.path.join(base_dir, output_file)
    print(f"📄 در حال نوشتن فایل خروجی در: {output_path}")
    
    with open(output_path, "w", encoding="utf-8") as f_out:
        f_out.write(f"# Project Code Dump — Clean Text Only — {datetime.now()}\n\n")
        count = 0

        for root, _, files in os.walk(base_dir):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in CODE_EXTENSIONS:
                    file_path = os.path.join(root, file)
                    clean_code = read_file_clean(file_path)

                    f_out.write("="*100 + "\n")
                    f_out.write(f"[{count+1}] FILE PATH: {file_path}\n")
                    f_out.write("-"*100 + "\n")
                    f_out.write(clean_code.strip() + "\n\n\n")
                    count += 1

    print(f"✅ فایل ساخته شد. {count} فایل کدی پردازش شد.")
    print(f"📁 مسیر فایل خروجی: {output_path}")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    dump_clean_code(current_dir)
